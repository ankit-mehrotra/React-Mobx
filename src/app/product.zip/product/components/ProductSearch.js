
import React, {Component} from "react";
import PropTypes from "prop-types";

export default class ProductSearch extends Component {
    constructor(props) {
        super(props);
    }
    
    componentDidMount() {
        
    }
    
    render() {
        return (
            <div> 
            <h2>ProductSearch</h2>
            </div>
        )
    }
} 


ProductSearch.defaultProps = {
    
}

ProductSearch.propTypes = {
    
}