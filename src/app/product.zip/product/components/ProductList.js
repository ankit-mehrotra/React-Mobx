import React from "react";

import {observer, inject} from "mobx-react";

@inject("productState")
@observer
export default class ProductList extends React.Component {

    componentDidMount() {
        this.props.productState.getProducts();
    }

    render() {

        let list= this.props.productState
             .products.map ( product => (
                 <li key={product.id}>
                    {product.name}
                 </li>
             ))

        return (
             
            <div>
                <ul>
                    {list}
                </ul>
            </div>

        )
    }
}